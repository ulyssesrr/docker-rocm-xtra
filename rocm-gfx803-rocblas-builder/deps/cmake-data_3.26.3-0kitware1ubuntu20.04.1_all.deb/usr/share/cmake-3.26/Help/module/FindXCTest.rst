.. cmake-module:: ../../Modules/FindXCTest.cmake
